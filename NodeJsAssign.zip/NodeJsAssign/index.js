'use strict';

const http = require('http');
var url = require('url')
var mongoUrl = "mongodb://localhost:27017/";
const qs = require('querystring');
const Enigma=require('./amit');
const eng= new Enigma('Magrethea');
var ObjectId = require('mongodb').ObjectId;
var MongoClient = require('mongodb').MongoClient;
let routes={
            'GET':  { 
                        '/getAllUsers':(req,res)=>
                        {
                                MongoClient.connect(mongoUrl,{ useNewUrlParser: true }, function(err, db){
                                    if (err){console.log("error", err);}
                                    else{
                                    var dbo = db.db("employee");
                                    //Find the first document in the customers collection:
                                    dbo.collection("customers").find({}).toArray(function(err, result) {
                                        if (err) throw err;
                                        console.log(result);
                                        db.close();
                                    });
                                    }
                                    });
                        },
                        '/getUser':(req,res)=>{
                            let body='';
                                 req.on('data', data=>{
                                                    body+=data;
                                                });
                                 req.on('end', ()=>{                     
                                    let params=qs.parse(body);
                                    let baseURI =url.parse(req.url,true);
                                    req.queryParams=baseURI.query;
                                    var id= req.queryParams.id;
                                    MongoClient.connect(mongoUrl,{ useNewUrlParser: true }, function(err, db){
                                if (err) throw err;
    
                                var dbo = db.db("employee");
                                var myquery = { _id: ObjectId(id) };
                                
                                dbo.collection("customers").find(myquery).toArray(function(err, result) {
                                    if (err) throw err;
                                   
                                    console.log(result);
                                    
                                    db.close();
                                  });
                                
                              });
                            });
                        }
                    },
            'POST': {
                    
                        '/login':(req,res)=>
                        {
                                let body='';
                            req.on('data', data=>{
                                body+=data;
                            });
                               
                            req.on('end', ()=>{
                                let params=qs.parse(body);
                                MongoClient.connect(mongoUrl,{ useNewUrlParser: true }, function(err, db) {
                                        var em=params['email'];
                                        var pass=params['password'];
                                     
                                        if (err)  {
                                            console.log("error", err);
                                        } else
                                         {
                                        var dbo = db.db("employee");
                                        var query = { email: em , password: pass };
                                        dbo.collection("customers").find(query).toArray(function(err, result) {
                                          if (err) throw err;
                                         
                                            console.log(result);
                                            if(result.length==0)
                                            {
                                               console.log("Wrong email or password !");
                                            }
                                            else{
                                                console.log("Success !");
                                            }
        
                                          db.close();
                                        });
                                    }
                                      });
                                    
                                });
                        },
                        '/register' :(req,res)=>
                        {
                                            
                             let body='';
                             req.on('data', data=>{
                                                body+=data;
                                            });
                                            
                            req.on('end', ()=>{
                                                
                                          let params=qs.parse(body);

                                                    MongoClient.connect(mongoUrl,{ useNewUrlParser: true }, function(err, db) {
                                                        if (err) {
                                                            console.log("error", err);
                                                        } else
                                                        {
                                                            var dbo = db.db('employee');
                                                            var pass=params['password'];
                                                            let encodeString=eng.encode(pass);


                                                            var myobj = { firstName: params['firstName'], lastName: params['lastName'], email:params['email'],password: encodeString, address: params['address'] };
                                                            dbo.collection("customers").insertOne(myobj, function(err, res) {
                                                                        if (err) throw err;
                                                                        console.log("1 document inserted");
                                                                        db.close();
                                                                        });
                                                        }
                                                    });
                                                });
                                            
                        }

                    },
            'PUT'  :{
                    '/updateUser' :(req,res)=>{
                        let body='';
                             req.on('data', data=>{
                                                body+=data;
                                            });

                             req.on('end', ()=>{                     
                                let params=qs.parse(body);
                                let baseURI =url.parse(req.url,true);
                                req.queryParams=baseURI.query;
                                var id= req.queryParams.id;
                                console.log(id);
                                
                                

                        MongoClient.connect(mongoUrl,{ useNewUrlParser: true }, function(err, db){
                            if (err) throw err;

                            var dbo = db.db("employee");
                            var myquery = { _id: ObjectId(id) };
                            console.log(myquery);
                            var newvalues = { $set: {firstName: "Mickey", address: "Canyon 123" } };
                            dbo.collection("customers").updateOne(myquery, newvalues, function(err, res) {
                              if (err) throw err;
                              console.log("1 document updated");
                              db.close();
                            });
                          });
                        });
                    }
                    },
            'NA':(req,res)=>{
                    res.writeHead(404);
                    res.end('URL not found...!');
                           }   
                
                
            }
function router(req, res){
    let baseURI =url.parse(req.url,true);
 
    
    let resolveRoute=routes[req.method][baseURI.pathname];
if(resolveRoute!=undefined)
{
    req.queryParams=baseURI.query;
    resolveRoute(req,res);
}else
{
    routes['NA'](req,res);
}
}
http.createServer(router).listen(3000, ()=>{
    console.log("Server is Running");
});