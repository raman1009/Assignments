 var emp =[ { empid:"4060", fname:"Maria", lname:"Anders", no:"9853762901"},
           { empid:"4061", fname:"Christina", lname:"Berglund", no:"873902785"},
		   { empid:"4062", fname:"Francisco", lname:"Chang", no:"7509386210"},
		   { empid:"4063", fname:"Roland", lname:"Mendel", no:"9887309761"},
		   { empid:"4064", fname:"Helen", lname:"Bennett", no:"8729065410" }
		];


var details = document.getElementById("show");
var para = "";
function fun(no){
	var det = [emp[no].empid,emp[no].fname,emp[no].lname,emp[no].no];
	para = "Id of Employee is :"+det[0]+"<br>";
	
	para = para+"Name of Employee is :"+det[1]+" "+det[2]+"<br>";
	para = para+"Phone no of the Employee is :"+det[3]+"<br>";
	console.log(para);
	details.innerHTML = para;
	return false;
}