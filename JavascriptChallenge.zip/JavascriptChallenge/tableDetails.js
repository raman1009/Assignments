
var emp =[ { empid:"4060", fname:"Maria", lname:"Anders", no:"9853762901", place:"Hyderabad", ecolor:"Black"},
           { empid:"4061", fname:"Christina", lname:"Berglund", no:"873902785",place:"Pune",ecolor:"Blue"},
		   { empid:"4062", fname:"Francisco", lname:"Chang", no:"7509386210",place:"Hyderabad",ecolor:"Black"},
		   { empid:"4063", fname:"Roland", lname:"Mendel", no:"9887309761",place:"Hyderabad", ecolor:"Green"},
		   { empid:"4064", fname:"Helen", lname:"Bennett", no:"8729065410",place:"Pune",ecolor:"Brown" }
		];

var text = "";
for (let i = 0; i < emp.length; i++) {
  text+="<tr>";
  text+="<td>"+emp[i].empid+"</td>";
  text+="<td>"+emp[i].fname+"</td>";
  text+="<td>"+emp[i].lname+"</td>";
  text+="<td>"+emp[i].no+"</td>";
  text+="<td>"
  text+='<a href="#" onclick="fun('+i+')">CLick to know more</a>'
  text+="</td>";
  text+="</tr>";
 }
 text+="</table>";
 document.getElementById("emp").innerHTML+=text;
 
 var details = document.getElementById("show");
	var para = "";
function fun(no){
	var det = [emp[no].empid,emp[no].fname,emp[no].lname,emp[no].no,emp[no].place,emp[no].ecolor ];
	para = "Id of Employee is :"+det[0]+"<br>";
	
	para = para+"Name of Employee is :"+det[1]+" "+det[2]+"<br>";
	para = para+"Phone no of the Employee is :"+det[3]+"<br>";
	para = para+"Location of the Employee is :"+det[4]+"<br>";
	para = para+"Eyecolor of the Employee is :"+det[5]+"<br>";
	console.log(para);
	details.innerHTML = para;
	
}

 



