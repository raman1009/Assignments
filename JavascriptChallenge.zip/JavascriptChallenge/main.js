function checkForm(form)
  {
    re=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if(!re.test(form.uname.value))
	{
		alert("Error: Incorrect Username!!");
		form.uname.focus();
		return false;
	}
	
	
	re= /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
	if(!re.test(form.pass.value))
	{
		alert("Error:Incorrect Password!!");
		form.pass.focus();
		return false;
	}
	
	alert("You entered a valid username and password");
	return true;
  }
   

     