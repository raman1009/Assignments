$(document).ready(function () {
    $('#dtVerticalScrollExample').DataTable({
      "scrollY": "200px",
      "scrollX": true,
    });
    $('.dataTables_length').addClass('bs-select');
  });